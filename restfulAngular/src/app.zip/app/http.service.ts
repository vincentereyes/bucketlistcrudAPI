import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HttpService {

  constructor(private _http: HttpClient){
  	// this.getTasks();
  	// this.getTask("5ace7cd481f86af24a6360a6")
  	// this.getPokemon()
  }

  getTasks(){
    // our http response is an Observable, store it in a variable
    // let tempObservable = this._http.get('/tasks');
    // // subscribe to the Observable and provide the code we would like to do with our data from the response
    // tempObservable.subscribe(data => console.log("Got our tasks!", data));
    return this._http.get('/tasks')
 }

 getTask(id){
 	let tempObservable = this._http.get('/' + id);
 	tempObservable.subscribe(data => console.log("Got our task!", data));
 }
 getPokemon(){
    let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
    let counter = 0;
    let ability;
    let ability2;
    bulbasaur.subscribe(data => {
    	ability = data.abilities[0].ability
    	ability2 = data.abilities[1].ability.name
    	console.log(data)
    	let pokemons = this._http.get(ability.url)
    	pokemons.subscribe(data => {
    		console.log(data.pokemon.length)
    	})
    // 	for (var i = 1; i < 5; i ++){
    // 	console.log("pokemon number", i)
    // 	let pokemon = this._http.get('https://pokeapi.co/api/v2/pokemon/' + i + '/');
    // 	pokemon.subscribe(data => {
    // 		console.log("another requuest")
    // 		for (var j = 0; j < data.abilities.length; j++){
    // 			if ((data.abilities[j].ability.name == ability) || (data.abilities[j].ability.name == ability2)){
    // 				console.log(ability)
    // 				console.log(ability2)
    // 				console.log("*******", data.abilities[j].ability.name)
    // 				this.counter++
    // 			}
    // 		}
    // 	})
    // 	console.log(counter)
    // }
    })


}

}

import { Component } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

   constructor(private _httpService: HttpService){}

   ngOnInit(){
   	
   }

   tasks = [];
   task;
   onButtonClick(): void { 
    this.getTasksFromService();
	}
	onButtonClickParam(id: String): void { 

    this.getTaskById(id)
	}

   getTasksFromService(){
   	let observable = this._httpService.getTasks();
    observable.subscribe(data => {
    	console.log("Got our tasks!", data.data);
    	this.tasks = data.data;
    })
   }
   getTaskById(id){
   	let observable = this._httpService.getTasks();
    observable.subscribe(data => {
    	id -= 1
    	this.task = data.data[id];
    })
   }
 }
